package com.healthsync.project.post.constant;

public enum Visibility {
    PRIVATE, PUBLIC
}
