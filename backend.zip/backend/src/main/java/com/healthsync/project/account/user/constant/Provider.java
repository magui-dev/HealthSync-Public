package com.healthsync.project.account.user.constant;

public enum Provider {
    GOOGLE, KAKAO, NAVER
}