//package com.healthsync.project.nutri.dto;
//
//import lombok.*;
//
//@Data
//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor
//public class NutriInfoDto {
//
//    private String foodName;
//    private String kcal;
//    private String carbs;   // 탄수화물
//    private String protein; // 단백질
//    private String fat;     // 지방
//}
/**
 0924. 오픈API 검색 테스트
 */