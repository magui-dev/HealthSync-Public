package com.healthsync.project.security.dto;

public record MeResponse(Long id, String email, String name, String roles) {}

