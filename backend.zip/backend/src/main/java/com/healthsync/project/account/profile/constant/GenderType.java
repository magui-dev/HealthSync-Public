package com.healthsync.project.account.profile.constant;

public enum GenderType {
    MALE,
    FEMALE
}
