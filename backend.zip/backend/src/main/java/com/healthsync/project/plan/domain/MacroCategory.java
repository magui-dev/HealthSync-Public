package com.healthsync.project.plan.domain;

public enum MacroCategory {
    CARB, PROTEIN, FAT
}

